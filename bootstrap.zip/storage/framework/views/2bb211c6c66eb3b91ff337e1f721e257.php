<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?></title>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/bootstrap-icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/simple-datatables/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/iconly/bold.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/perfect-scrollbar/perfect-scrollbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/sweetalert2/sweetalert2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/fontawesome/all.min.css')); ?>">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets\img\apple-icon.png')); ?>">
</head>

<body>
    <div id="app">
        <div id="sidebar" class="active">
            <div class="sidebar-wrapper active">
                <div class="sidebar-header">
                    <div class="d-flex justify-content-between">
                        <div class="logo">
                            <a href="/">
                                <p style="font-size:70% ;"><strong><i class="bi bi-flower1"></i> BK ADMINISTRATION</strong></p>
                            </a>
                        </div>
                        <div class="toggler">
                            <a href="#" class="sidebar-hide d-xl-none d-block"><i class="bi bi-x bi-middle"></i></a>
                        </div>
                    </div>
                </div>
                <div class="sidebar-menu">
                    <ul class="menu">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <?php if(\Session::has('message')): ?>
                            <li class="sidebar-item">
                                <div class="alert alert-success alert-dismissible show fade">
                                    <?php echo \Session::get('message'); ?>

                                    <button type="button" class="btn-close" data-bs-dismiss="alert"
                                        aria-label="Close"></button>
                                </div>
                            <?php endif; ?>
                            <?php if(\Session::has('error')): ?>
                                <div class="alert alert-danger alert-dismissible show fade">
                                    <?php echo \Session::get('error'); ?>

                                    <button type="button" class="btn-close" data-bs-dismiss="alert"
                                        aria-label="Close"></button>
                                </div>
                            </li>
                            <?php endif; ?>

                        <li class="sidebar-title">Menu</li>

                        <?php if( "level"): ?>
                        <li class="sidebar-item <?php echo e(Request::is('/') ? 'active' : ''); ?> ">
                            <a href="/" class='sidebar-link '>
                                <i class="bi bi-grid-fill"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <li class="sidebar-item <?php echo e($title=='Siswa | BK Administration' ? 'active' : ''); ?>">
                            <a href="/siswa" class='sidebar-link'>
                                <i class="bi bi-file-earmark-medical-fill"></i>
                                <span>Data Siswa</span>
                            </a>
                        </li>
                       
                        
                        <?php if(session('user')[0][4] == 'Admin'): ?>
                        <li class="sidebar-item <?php echo e($title =='Users | BK Administration' ? 'active':''); ?>">
                            <a href="/users" class='sidebar-link'>
                                <i class="bi bi-people-fill"></i>
                                <span>Users</span>
                            </a>
                        </li>

                        <li class="sidebar-title">Management Data</li>

                        <li class="sidebar-item <?php echo e($title=='Jenis Pelanggaran | BK Administration' ? 'active' : ''); ?>">
                            <a href="/pelanggaran" class='sidebar-link'>
                                <i class="bi bi-journal-bookmark-fill"></i>
                                <span>Jenis Pelanggaran</span>
                            </a>
                        </li>



                        <li class="sidebar-item  <?php echo e($title=='Jenis Kebaikan | BK Administration' ? 'active' : ''); ?>">
                            <a href="/kebaikan" class='sidebar-link'>
                                <i class="bi bi-receipt"></i>
                                <span>Jenis Kebaikan</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        

                        
                        <li class="sidebar-title">Log Management</li>

                        <li class="sidebar-item <?php echo e($title=='Log Perilaku | BK Administration' ? 'active' : ''); ?>">
                            <a href="/logperilaku" class='sidebar-link'>
                                <i class="bi bi-building"></i>
                                <span>Log Perilaku</span>
                            </a>
                        </li>
                       


                        <li class="sidebar-item  <?php echo e($title=='Tambah Log Siswa | BK Administration' ? 'active' : ''); ?>">
                            <a href="/logmanagement" class='sidebar-link'>
                                <i class="bi bi-file-earmark-arrow-down-fill"></i>
                                <span>Tambah Log Siswa</span>
                            </a>
                        </li>
                       


                        <li class="sidebar-title">Action</li>

                        
                        <li class="sidebar-item  ">
                            <button type="button" class="btn btn-lg btn-block sidebar-link"data-bs-toggle="modal" data-bs-target="#info">
                                <i class="bi bi-box-arrow-left">
                                    </i><span>Log Out</span></button>
                        </li>

                    </ul>
                </div>
                <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
            </div>
        </div>

        <!--Edit Profile Modal -->
        <div class="modal fade text-left" id="dadaf" tabindex="-1"
            role="dialog" aria-labelledby="myModalLabel130"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable"
                role="document">
                <div class="modal-content">
                    <div class="modal-header bg-primary">
                        <h5 class="modal-title white" id="myModalLabel130">
                            Edit Profile
                        </h5>
                        <button type="button" class="close"
                            data-bs-dismiss="modal" aria-label="Close">
                            <i data-feather="x"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="/edituserutama" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group position-relative has-icon-left mb-4">
                                <label for="nik">NIK</label>
                                <input type="text" class="form-control form-control-xl" name="nik" value="" readonly>
                                <div class="form-control-icon">
                                    <i class="bi bi-credit-card"></i>
                                </div>
                            </div>
                            <div class="form-group position-relative has-icon-left mb-4">
                                <label for="editname">Name</label>
                                <input type="text" class="form-control form-control-xl" name="editname" placeholder="Input Your Correct Name" value="" required>
                                <div class="form-control-icon">
                                    <i class="bi bi-person"></i>
                                </div>
                            </div>

                            <div class="form-group position-relative has-icon-left mb-4">
                                <label for="editemail">Email</label>
                                <input type="email" class="form-control form-control-xl" name="editemail" placeholder="Input Your Correct Email" value="" required>
                                <div class="form-control-icon">
                                    <i class="bi bi-envelope"></i>
                                </div>
                            </div>

                            <div class="form-group position-relative has-icon-left mb-4">
                                <label for="editphone">Phone</label>
                                <input type="number" class="form-control form-control-xl" name="editphone" placeholder="Input Your Correct Phone Number" value="" required>
                                <div class="form-control-icon">
                                    <i class="bi bi-phone"></i>
                                </div>
                            </div>

                            <div class="form-group position-relative has-icon-left mb-4">
                                <label for="editalamat">Address</label>
                                <input type="text" class="form-control form-control-xl" name="editalamat" placeholder="Input Your Correct Adress" value="" required>
                                <div class="form-control-icon">
                                    <i class="bi bi-house"></i>
                                </div>
                            </div>
                    </div>
                    <div class="modal-footer">
                            <button type="button"
                                class="btn btn-light-secondary"
                                data-bs-dismiss="modal">
                                <i class="bx bx-x d-block d-sm-none"></i>
                                <span class="d-none d-sm-block">Close</span>
                            </button>
                            <button type="submit"  class="btn btn-primary ml-1">
                                Accept
                            </button>
                        </form>
                        </div>
                    </div>
            </div>
        </div>

        <!--info theme Modal -->
        <div class="modal fade text-left" id="info" tabindex="-1"
            role="dialog" aria-labelledby="myModalLabel130"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable"
                role="document">
                <div class="modal-content">
                    <div class="modal-header bg-primary">
                        <h5 class="modal-title white" id="myModalLabel130">
                            Logout
                        </h5>
                        <button type="button" class="close"
                            data-bs-dismiss="modal" aria-label="Close">
                            <i data-feather="x"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                       Are you sure you want to logout?
                    </div>
                    <div class="modal-footer">
                        <form action="/logout" method="post">
                            <?php echo csrf_field(); ?>
                            <button type="button"
                                class="btn btn-light-secondary"
                                data-bs-dismiss="modal">
                                <i class="bx bx-x d-block d-sm-none"></i>
                                <span class="d-none d-sm-block">Close</span>
                            </button>
                            <button type="submit" name="logout" class="btn btn-danger ml-1">
                                Accept
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div id="main">
            <header class="mb-3">
                <a href="#" class="burger-btn d-block d-xl-none">
                    <i class="bi bi-justify fs-3"></i>
                </a>
            </header>
            <?php echo $__env->yieldContent('content'); ?>
            <footer>
                <div class="footer clearfix mb-0 text-muted">
                    <div class="float-start">
                        <p>2024 &copy; Cici Lalang</p>
                    </div>
                    <div class="float-end">
                        <p>Crafted with <span class="text-danger">❤</span> by <a
                                href="https://github.com/haylill/Laravel-Sistem-Administrasi-Kantor">NPC</a></p>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script src="<?php echo e(asset('assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/extensions/sweetalert2.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/apexcharts/apexcharts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pages/dashboard.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/simple-datatables/simple-datatables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <script>
        // Simple Datatable
        let table1 = document.querySelector('#table1');
        let dataTable = new simpleDatatables.DataTable(table1);
    </script>
</body>

</html>
<?php /**PATH D:\DOCUMENTS3\lala\web\laravel-Sistem-AdminBK\adminbk\resources\views/home/tamplate/tamplate.blade.php ENDPATH**/ ?>