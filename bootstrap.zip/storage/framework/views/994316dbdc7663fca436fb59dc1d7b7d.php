
    
<?php $__env->startSection('content'); ?>

<div class="page-heading">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3>Siswa</h3>
                <p class="text-subtitle text-muted">For siswa to check they list</p>
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Siswa</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <section class="section">
        <div class="card">
            <div class="card-header">
                <?php if(session('user')[0][4] == "Admin"): ?>
                <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                    data-bs-target="#inlineForm">
                    Custom Data Siswa
                </button>
                <?php endif; ?>
                <!--login form Modal -->
                <div class="modal fade text-left" id="inlineForm" tabindex="-1"
                    role="dialog" aria-labelledby="myModalLabel33" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable"
                        role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalScrollableTitle">
                                    Custom Data Siswa</h5>
                                <button type="button" class="close" data-bs-dismiss="modal"
                                    aria-label="Close">
                                    <i data-feather="x"></i>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div>
                                    <p>Harap yang Mengakses Hanya Admin Atau Petugas Yang terkait</p>    
                                </div>
                                <div class="modal-footer">
                                    <div class="d-flex justify-content-end">
                                        
                                        <a href="https://docs.google.com/spreadsheets/d/1FmwFDcO8cr7dWOnOJpw3um4Op3SWp9C1c_EeKU8xNHM/edit#gid=0" target="_blank"  class="btn btn-primary me-1 mb-1">Submit</a>                                        
                                        <button class="close btn btn-light-secondary me-1 mb-1" data-bs-dismiss="modal"
                                        aria-label="Close"
                                            >Kembali</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-striped" id="table1">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>Jurusan</th>
                            <th>Tahun Ajaran</th>
                            <th>Tanggal Lahir</th>
                            <th>Alamat</th>
                            <th>Point</th>
                        </tr>
                    </thead>
                    <tbody>  
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                        <tr>
                            <td><?php echo e($user[0]); ?></td>
                            <td><?php echo e($user[1]); ?></td>
                            <td><?php echo e($user[2]); ?></td>
                            <td><?php echo e($user[3]); ?></td>
                            <td><?php echo e($user[4]); ?></td>
                            <td><?php echo e($user[5]); ?></td>
                            <td><?php echo e($user[6]); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
                    </tbody>
                </table>
            </div>
        </div>

    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home/tamplate/tamplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DOCUMENTS3\lala\web\laravel-Sistem-AdminBK\adminbk\resources\views/home/siswas.blade.php ENDPATH**/ ?>